const Detail ={
   
    productData:[
        {
        id: 1,
        img:'./img/book1.webp',
        title:'JThe Galactic Time Travelers',
        desc:'',
        price: 46,
    },
    {
        id: 2,
        img:'./img/book2.webp',
        title:'Mystery of the Robot Planet',
        desc:'',
        price: 49,
    },
    {
        id: 3,
        img:'./img/book3.webp',
        title:'Adventures in the Microverse',
        desc:'',
        price: 58,
    },
    {
        id: 4,
        img:'./img/book4.webp',
        title:'The Lost City of Future Earth',
        desc:'',
        price: 12,
    },
    
    {
        id: 5,
        img:'./img/book5.webp',
        title:'Pirates the Nebula Treasure',
        desc:'',
        price: 39,
    },
    {
        id: 6,
        img:'./img/book6.webp',
        title:'The Alien School on Mars',
        desc:'',
        price: 40,
    },
    {
        id: 7,
        img:'./img/book7.webp',
        title:'The Starship of Lost Dreams',
        desc:'',
        price: 30,
    },
    {
        id: 8,
        img:'./img/book8.webp',
        title:'Journey to the Parallel Universe',
        desc:'',
        price: 26,
    },
    {
        id: 9,
        img:'./img/book9.webp',
        title:'The Invisible Inventor Lab',
        desc:'',
        price: 43,
    },
    {
        id: 10,
        img:'./img/book10.webp',
        title:'Moon Base Alpha: The Lunar',
        desc:'',
        price: 40,
    },
    {
        id: 11,
        img:'./img/book11.webp',
        title:'Mystery of the Robot Planet',
        desc:'',
        price: 67,
    },
    {
        id: 12,
        img:'./img/book2.webp',
        title:'the Nebula Treasure',
        desc:'',
        price: 56,
    },

    ]

    
}
   
export default Detail;
